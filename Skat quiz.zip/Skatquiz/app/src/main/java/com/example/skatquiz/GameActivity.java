package com.example.skatquiz;

public class GameActivity {
}
