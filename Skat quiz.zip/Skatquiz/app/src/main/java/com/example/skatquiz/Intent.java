package com.example.skatquiz;

public class Intent extends android.content.Intent {
    public Intent(MainActivity2 mainActivity2, Class<GameActivity> gameActivityClass) {
    }
}
