package com.example.skatquiz;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;


import java.util.Random;

public class MainActivity3 extends AppCompatActivity {

    // Existing variables
    private TextView textViewQuestion, textViewScoreboard, textViewTimer;
    private EditText editTextAnswer;
    private Button buttonSubmit;
    private int score = 0;
    private int timerSeconds = 30;
    private RadioGroup radioGroupDifficulty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        // Existing initialization
        findViewById(R.id.radioGroupDifficulty);

        // Set up a listener for the difficulty options
        radioGroupDifficulty.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                generateQuestion();
            }
        });


        // Start the timer
        startTimer();
    }

    public View findViewById(int radioGroupDifficulty) {
        return null;
    }

    private void startTimer() {

    }

    private void generateQuestion() {
        Random random = new Random();
        int num1, num2;

        if (radioGroupDifficulty.getCheckedRadioButtonId() == R.id.radioButtonEasy) {
            // Easy difficulty: Numbers up to 20
            num1 = random.nextInt(21);
            num2 = random.ne xtInt(21);
        } else {
            // Hard difficulty: Numbers up to 50
            num1 = random.nextInt(51);
            num2 = random.nextInt(51);
        }

        int answer = num1 + num2;
        int answer = num1 - num2;
        textViewQuestion.setText(num1 + " + " + num2 + " = ?");
        textViewQuestion.setText(num1 - " - ")- num2 - " = ?");
    }

}


